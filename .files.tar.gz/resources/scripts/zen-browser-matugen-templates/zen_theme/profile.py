import configparser
from pathlib import Path
import typing


def read_ini(path: Path) -> typing.Optional[configparser.ConfigParser]:
    if not path.is_file():
        return None
    cfg = configparser.ConfigParser()
    cfg.read(path)
    return cfg


def resolve_profile(
    config_dir: Path, raw_path: str, is_relative: str
) -> typing.Optional[Path]:
    if not raw_path:
        return None
    candidate = config_dir / raw_path if is_relative == "1" else Path(raw_path)
    return candidate if candidate.is_dir() else None


def find_profile(config_dir: Path) -> typing.Optional[Path]:
    # 1. Check installs.ini
    if cfg := read_ini(config_dir / "installs.ini"):
        for section in cfg.sections():
            if cfg.has_option(section, "Default"):
                raw = cfg.get(section, "Default").rstrip("/")
                candidate = config_dir / raw
                if candidate.is_dir():
                    return candidate

    # 2. Check profiles.ini
    if cfg := read_ini(config_dir / "profiles.ini"):
        for section in cfg.sections():
            if cfg.get(section, "Default") == "1":
                raw = cfg.get(section, "Path", fallback="")
                is_rel = cfg.get(section, "IsRelative", fallback="0")
                if profile := resolve_profile(config_dir, raw, is_rel):
                    return profile

        if cfg.has_section("Profile0"):
            raw = cfg.get("Profile0", "Path", fallback="")
            is_rel = cfg.get("Profile0", "IsRelative", fallback="0")
            if profile := resolve_profile(config_dir, raw, is_rel):
                return profile
    return None
