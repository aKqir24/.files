import os
import sys
from pathlib import Path


def install_themes(
    config_dir: Path,
    profile: Path,
    matugen_input: Path,
    matugen_output: Path,
    website_templates: Path,
    auto_yes: bool,
):
    if not matugen_output.is_dir():
        print(
            f"ERR: Matugen output folder `{matugen_output}` is not found!!",
            file=sys.stderr,
        )
        sys.exit(1)

    if not matugen_input.is_dir():
        print(
            f"ERR: Matugen input templates folder `{matugen_input}` is not found!!",
            file=sys.stderr,
        )
        sys.exit(1)

    chrome_dir = profile / "chrome"
    chrome_dir.mkdir(parents=True, exist_ok=True)
    content_file = chrome_dir / "userContent.css"

    if any(chrome_dir.iterdir()):
        print("INF: Zen styles are already installed!!")
        print(
            "INF: If it is not working please run matugen and configure it properly!!\n     And then rerun this script:)"
        )
    else:
        os.symlink(
            matugen_input / "zen-userChrome.css", chrome_dir / "userChrome.css"
        )
        os.symlink(matugen_input / "zen-userContent.css", content_file)
        print("INF: Zen styles are successfully installed!!")

    if auto_yes:
        install_website_themes = "Y"
        print("Do you want to install the website themes? [Y/n] Y")
    else:
        install_website_themes = input(
            "Do you want to install the website themes? [Y/n] "
        )

    if install_website_themes.upper() == "N":
        return

    website_dir = chrome_dir / "websites"
    if not website_dir.is_dir():
        if not website_templates.is_dir():
            print(
                f"ERR: Website templates folder `{website_templates}` does not exist!!",
                file=sys.stderr,
            )
            sys.exit(1)
        os.symlink(website_templates, website_dir)

    imports = [
        f'@import url("{chrome_dir}/colors.css");',
        f'@import url("{website_dir}/bitwarden.css");',
        f'@import url("{website_dir}/github.css");',
        f'@import url("{website_dir}/youtube.css");',
    ]

    lines = (
        content_file.read_text(encoding="utf-8").splitlines()
        if content_file.exists()
        else []
    )
    cleaned_lines = [l for l in lines if l.strip() not in imports]

    if cleaned_lines:
        new_lines = [cleaned_lines[0]] + imports + cleaned_lines[1:]
    else:
        new_lines = imports

    content_file.write_text("\n".join(new_lines) + "\n", encoding="utf-8")
