import argparse
import sys
from pathlib import Path

from .config import (
    get_default_config_dir,
    get_default_matugen_input,
    get_default_matugen_output,
    get_default_website_templates,
)
from .installer import install_themes
from .profile import find_profile


def main():
    default_config = get_default_config_dir()
    default_matugen_input = get_default_matugen_input(default_config)
    default_matugen_output = get_default_matugen_output()
    default_website_templates = get_default_website_templates()

    epilog_text = """
Matugen configuration example (e.g. ~/.config/matugen/config.toml):

[templates.zen-userchrome]
input_path = '<YOUR_TEMPLATE_DIR>/zen-userchrome.css'
output_path = '~/.cache/matugen/zen-userChrome.css'

[templates.zen-usercontent]
input_path = '<YOUR_TEMPLATE_DIR>/zen-usercontent.css'
output_path = '~/.cache/matugen/zen-userContent.css'

[templates.firefox-website-colors]
input_path = "<YOUR_TEMPLATE_DIR>/firefox-colors.css"
output_path = "~/.cache/matugen/firefox-colors.css"
"""

    parser = argparse.ArgumentParser(
        description="Install Zen Browser theme styles and link Matugen themes.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=epilog_text,
    )
    parser.add_argument(
        "-c",
        "--config-dir",
        type=Path,
        help="Custom Zen root folder containing profiles and config data",
        default=default_config,
    )
    parser.add_argument(
        "-m",
        "--matugen-output",
        type=Path,
        help="Custom matugen-theme output folder containing generated colors",
        default=default_matugen_output,
    )
    parser.add_argument(
        "-i",
        "--matugen-input",
        type=Path,
        help="Custom matugen-input folder containing template files (zen-userChrome.css, zen-userContent.css)",
        default=default_matugen_input,
    )
    parser.add_argument(
        "-w",
        "--websites-templates",
        type=Path,
        help="Custom website templates folder",
        default=default_website_templates,
    )
    parser.add_argument(
        "-y",
        "--yes",
        action="store_true",
        help="Automatically answer yes to all prompts",
    )
    args = parser.parse_args()

    config_dir = args.config_dir
    if not any(arg in sys.argv for arg in ("-c", "--config-dir")):
        print("INF: Looking for the 'zen' folder")

    if not config_dir.is_dir():
        print(f"ERR: Zen config dir not found: {config_dir}", file=sys.stderr)
        sys.exit(1)
    else:
        print(f"INF: Using config directory: {config_dir}")

    print("INF: Figuring out, the default zen profile...")
    profile = find_profile(config_dir)

    if not profile or not profile.is_dir():
        print("ERR: Could not determine Zen profile directory.", file=sys.stderr)
        sys.exit(1)

    install_themes(
        config_dir=config_dir,
        profile=profile,
        matugen_input=args.matugen_input,
        matugen_output=args.matugen_output,
        website_templates=args.websites_templates,
        auto_yes=args.yes,
    )
