import os
import sys
from pathlib import Path


def get_default_config_dir() -> Path:
    for i, arg in enumerate(sys.argv):
        if arg in ("-c", "--config-dir") and i + 1 < len(sys.argv):
            return Path(sys.argv[i + 1])
    if sys.platform == "darwin":
        return Path.home() / "Library/Application Support/Zen Browser"
    else:
        xdg_config = Path(
            os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config")
        )
        cfg = xdg_config / "zen"
        if not cfg.is_dir():
            legacy = Path.home() / ".zen"
            if legacy.is_dir():
                return legacy
        return cfg


def get_default_matugen_input(config_dir: Path) -> Path:
    return config_dir / "templates"


def get_default_matugen_output() -> Path:
    return Path.home() / ".cache/matugen"


def get_default_website_templates() -> Path:
    return Path.home() / ".files/resources/matugen-themes/websites"
