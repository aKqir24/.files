#!/usr/bin/env python3
from zen_theme import main

if __name__ == "__main__":
    main()
