return {
    fg = "{{colors.primary.default.hex}}",
    bg = "{{colors.surface_container.default.hex}}",
}
